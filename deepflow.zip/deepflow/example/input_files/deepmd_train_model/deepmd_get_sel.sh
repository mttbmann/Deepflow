#!/usr/bin/zsh

### 12 processes, all on one node
#SBATCH --nodes=1
#SBATCH --ntasks=24

### Limit for maximum memory per slot (in MB)
#SBATCH --mem-per-cpu=3900

#SBATCH --job-name=deepmd_get_sel

#SBATCH --time=1:00:00

#SBATCH --account=simcat

#SBATCH --output=deepmd_sel.out



export DEEPMD_KIT_PATH=~/deepmd_gpu/installation/
source $DEEPMD_KIT_PATH

wait
dp neighbor-stat -s ../dpgen_data_conversion/training_data -r 5.0 -t C S O H N
